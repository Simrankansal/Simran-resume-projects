import "./TripStyle.css"
import TripData from"./TripData"
import Trip1 from "../asets/trip1.jpg"
import Trip2 from "../asets/trip2.jpg"
import Trip3 from "../asets/trip3.jpg"
function Trip(){
    return(
        <div className="trip">
        <h1>Recent Trips</h1>
        <p>You can discover unique destinations using Google Map.</p>
        <div className="tripcard">
            <TripData
            image={Trip1}
            heading ="Trip in Indonesia"
            text="Indonesia,officially the Republic of Indonesia, is a country in South Asia and Oceania between the Indian and Pacific oceans.It consists of over 17,000 islands."
            />
             <TripData
            image={Trip2}
            heading ="Trip in France"
            text="France's scenery is as diverse as it is beautiful, with the glittering coastlines of the French Riviera, the patchwork fields of the Loire Valley, the snow-capped Alps and centuries old harbor towns of Normandy. This, of course, is hugely appealing for lovers of the great outdoors."
            />
             <TripData
            image={Trip3}
            heading ="Trip in Malasiya"
            text="Malaysia is one of the Southeast Asian countries, on a peninsula of the Asian continent, to a certain extent; it can be recognized as part of the Asian continent and the northern part of the island of Borneo. In efforts to diversify the economy and make Malaysia’s economy is not dependent on the export-oriented government to increase tourism in Malaysia."
            />
        </div>
        </div>
    )
}
export default Trip;