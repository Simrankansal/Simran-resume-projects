import "./AboutUsStyle.css"

function Aboutus(){
	return(

		<div className ="about-container">
		<h1> Our History</h1>
		<p> Trippy is owned and managed by Trippy .In Pvt. Ltd., a leading brand in web designing services an e-commerce solution. </p>
		<h1>Our MIssion</h1>
		<p>Tourism is the largest and fastest-growing industry across the world. It is a source of revenue and employment. It also gives the opportunity for people to understand the culture, civilization, and religious aspects of a country.</p>
		<h1>Our Vission</h1>
		<p>Tourism is the largest and fastest-growing industry across the world. It is a source of revenue and employment. It also gives the opportunity for people to understand the culture, civilization, and religious aspects of a country.</p>
		
		</div>
	);
}
export default Aboutus