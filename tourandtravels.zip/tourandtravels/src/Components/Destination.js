import des1 from "../asets/des1.jpg"
import des2 from "../asets/des2.jpg"
import des3 from "../asets/des3.jpg"

import DestinationData from "./DestinationData";
import "./DestinationStyles.css";
const Destination = () => {
    return (
        <div className="destination">
            <h1> Popular Destinations</h1>
            <p>Tour give you the opportunity to see alot within single frame.  
            </p>
         <DestinationData
         className="first-des"
         heading="Taal Volcano , Batangs"
         text="Tourism is the largest and fastest-growing industry across the world. It is a source of revenue and employment. It also gives the opportunity for people to understand the culture, civilization, and religious aspects of a country. There are many countries whose main source of revenue is Tourism.
         "
         img1={des1}
         img2={des2}
        
         />
         <DestinationData
        className="first-des-reverse"
         heading="Mt. Daguldul, Batangas"
         text="Tourism is the largest and fastest-growing industry across the world. It is a source of revenue and employment. It also gives the opportunity for people to understand the culture, civilization, and religious aspects of a country. There are many countries whose main source of revenue is Tourism.
         "
         img1={des3}
         img2={des2}
        
         />
         
            </div>
    );
};
export default Destination