import React from 'react';
import Login from '../components/Login';
import TaskManagerPage from './task-manager';

const LoginPage = () => {
  return (
    <div>
      <Login />
    </div>
  );
};

export default LoginPage;
