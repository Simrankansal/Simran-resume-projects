import React from 'react'

function MyApp() {
    return (
        <div>MyApp</div>
    )
}

export default MyApp