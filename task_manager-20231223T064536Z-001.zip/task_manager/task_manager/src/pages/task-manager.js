import React, { useEffect, useState } from 'react';
import AddTask from '../components/AddTask';
import TaskList from '../components/TaskList';
import TaskContextProvider from '../TaskContext';
import Login from '../components/Login';
import styles from '../styles/globals.css';
import { useRouter } from 'next/router';


const TaskManagerPage = () => {

  const [user, setUser] = useState();
  const Router = useRouter();
  useEffect(() => {
    let storedName = localStorage.getItem('username');
    // console.log(storedName);
    setUser(storedName);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("username");
    Router.push('/');
  }

  return (
    <div>
      {user ? (<div className="main-container">
        <TaskContextProvider>
          <button className='logoutBtn' onClick={handleLogout} type="submit"  >Logout</button>
          <AddTask />
          <TaskList />
        </TaskContextProvider>
      </div>) : (
        Router.push('/')
      )}


    </div>
  )
};

export default TaskManagerPage;
