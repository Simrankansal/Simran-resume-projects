import React, { useContext, useState } from 'react';
import { useRouter } from 'next/router';
import { TaskContext } from '../TaskContext';
import styles from '../styles/globals.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  // const { dispatch } = useContext(TaskContext);
  const router = useRouter();

  const handleLogin = (e) => {
    e.preventDefault();

    if (username === 'Simran' && password === 'Simran123') {
      setError('');
      localStorage.setItem('username', username);
      router.push('/task-manager');
    } else {
      setError('Invalid username or password');
    }

  };

  return (
    <div className='main-container'>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <br />
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <br />
        <div className="login-container">
          <button className='LoginBtn' type="submit">Login</button>
          {error && <p>{error}</p>}
        </div>
      </form>
    </div>
  );
};

export default Login;
