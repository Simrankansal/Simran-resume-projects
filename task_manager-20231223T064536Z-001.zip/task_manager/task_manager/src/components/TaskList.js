import React, { useContext, useState, useEffect } from 'react';
import { TaskContext } from '../TaskContext';
import EditTask from './EditTask';

const TaskList = () => {

  const [count, setCount] = useState(0);
  const abc = count;
  console.log(abc);
  const [compTask, getTask] = useState();
  const { tasks, dispatch } = useContext(TaskContext);
  const handleDelete = (id) => {
    dispatch({ type: 'DELETE_TASK', payload: id });
  };

  const handleToggle = (id, status) => {
    dispatch({ type: 'TOGGLE_TASK', payload: id });
    status ? setCount(count - 1) : setCount(count + 1);
    status ? localStorage.setItem('completed_task', abc - 1) : localStorage.setItem('completed_task', abc + 1);
    status ? getTask(abc - 1) : getTask(abc + 1);
  };

  useEffect(() => {
    let storedValue = localStorage.getItem('completed_task');
    getTask(storedValue);
  }, [])

  return (
    <div className='task-container'>
      <h2>Task List</h2>
      {tasks.length === 0 ? (
        <p>No tasks yet</p>
      ) : (
        <ul>
          <p>Total Tasks:- {tasks.length}</p> <p>Completed Tasks:- {compTask <= 0 ? 0 : compTask}</p>
          {tasks.map((task) => (
            <li key={task.id}>
              <p>
                <span style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
                  {task.name}
                </span>
              </p>
              <div className='button-group'>
                <button className='compBtn' onClick={() => handleToggle(task.id, task.completed)}>
                  {task.completed ? 'Uncompleted' : 'Completed'}

                </button>
                <button className="delBtn" onClick={() => handleDelete(task.id)}>Delete</button>
                <EditTask task={task} />
              </div><br />

            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default TaskList;
