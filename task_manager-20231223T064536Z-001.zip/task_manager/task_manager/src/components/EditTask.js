// src/components/EditTask.js
import React, { useState, useContext } from 'react';
import { TaskContext } from '../TaskContext';
import styles from '../styles/globals.css';

const EditTask = ({ task }) => {
  const [editMode, setEditMode] = useState(false);
  const [editedTaskName, setEditedTaskName] = useState(task.name);
  const { dispatch } = useContext(TaskContext);

  const handleEditTask = () => {
    if (editedTaskName.trim() !== '') {
      dispatch({ type: 'EDIT_TASK', payload: { id: task.id, name: editedTaskName } });
      setEditMode(false);
    }
  };

  return (
    <div>
      {editMode ? (
        <div className='button-group'>
          <input
            type="text"
            value={editedTaskName}
            onChange={(e) => setEditedTaskName(e.target.value)}
          />
          <button className='addBtn' onClick={handleEditTask}>Save</button>
          <button className='delBtn' onClick={() => setEditMode(false)}>Cancel</button>
        </div>
      ) : (
        <div>
          {/* <span style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
            {task.name}
          </span> */}
          <button className='editBtn' onClick={() => setEditMode(true)}>Edit</button>
        </div>
      )}
    </div>
  );
};

export default EditTask;
