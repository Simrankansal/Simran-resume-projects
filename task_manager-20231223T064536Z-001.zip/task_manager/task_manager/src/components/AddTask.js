import React, { useState, useContext } from 'react';
import { TaskContext } from '../TaskContext';

const AddTask = () => {
  const [taskName, setTaskName] = useState('');
  const { dispatch } = useContext(TaskContext);

  const handleAddTask = (e) => {
    e.preventDefault();
    if (taskName.trim() !== '') {
      dispatch({
        type: 'ADD_TASK',
        payload: { id: new Date().getTime().toString(), name: taskName, completed: false },
      });
      setTaskName('');
    }
  };

  return (
    <div className='add-container'>
      <h2>Add Task</h2>
      <form onSubmit={handleAddTask}>
        <div className='button-group'>
          <input
            type="text"
            value={taskName}
            onChange={(e) => setTaskName(e.target.value)}
            placeholder="Enter task name"
          />
          <button className="addBtn" type="submit">Add</button>
        </div>
      </form>
    </div>
  );
};

export default AddTask;
